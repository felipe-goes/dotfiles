const int testando = 150;

int print_testando();
