#include "modulo/teste.hpp"

int print_testando() {
  return testando;
}
