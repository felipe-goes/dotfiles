#include <gtest/gtest.h>
#include "modulo/teste.hpp"

TEST(TestModulo, Basic) { EXPECT_EQ(print_testando(), 150); }
