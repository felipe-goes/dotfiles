#include "RenameClass.hpp"

RenameClass::RenameClass(){}

RenameClass::~RenameClass(){}
