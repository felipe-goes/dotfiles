#pragma once

class RenameClass
{
private:

protected:

public:
  RenameClass();
  ~RenameClass();

};
