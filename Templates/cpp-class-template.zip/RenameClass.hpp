#pragma once

#include "RenameInheritClass.hpp"

class RenameClass
{
public:
  RenameClass();
  ~RenameClass();

};
