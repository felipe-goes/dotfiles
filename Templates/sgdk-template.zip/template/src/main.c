#include <genesis.h>
#include "vdp_bg.h"

int main() {
  VDP_drawText("Hello Sega!", 10, 13);
  VDP_drawText("Texto", 5, 5);

  while (1) {
    SYS_doVBlankProcess();
  }
  return (0);
}
